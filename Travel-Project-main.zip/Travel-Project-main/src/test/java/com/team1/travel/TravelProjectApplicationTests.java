package com.team1.travel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
